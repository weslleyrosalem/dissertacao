import torch
import numpy as np
from itertools import product
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.preprocessing import StandardScaler
from data_preparation import load_and_preprocess_data, create_sequences
from train import train_model
from model import Encoder
from bayes_opt import BayesianOptimization
import torch.nn as nn
import torch.optim as optim

# Constants and Hyperparameters
SEQ_LENGTH = 60  
d_model = 64
input_dim = d_model
nhead = 4
dim_feedforward = 256
batch_size = 64
num_epochs = 10

# Load and preprocess data
ts = load_and_preprocess_data()
scaler = StandardScaler()
ts_scaled = scaler.fit_transform(ts.values.reshape(-1, 1))
X, y = create_sequences(ts_scaled, SEQ_LENGTH, d_model)

# Train-Test Split
train_size_loc = ts.index.get_loc("2021-02-07")

if isinstance(train_size_loc, slice):
    print("Multiple indices found for the date. Using the start of the slice.")
    train_size = train_size_loc.start
elif isinstance(train_size_loc, int):
    train_size = train_size_loc

# Define the search space for Bayesian optimization
pbounds = {'learning_rate': (0.0001, 0.1),
           'num_layers': (1, 5)}

# Define the function to optimize
def optimize_model(learning_rate, num_layers):
    # Initialize the model, loss, and optimizer
    model = Encoder(d_model, nhead, num_layers, dim_feedforward)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    # Train the model
    train_loss, val_loss = train_model(model, X, y, train_size, batch_size, num_epochs, criterion, optimizer)

    # Return the validation loss
    return -val_loss

# Perform Bayesian optimization
optimizer = BayesianOptimization(f=optimize_model, pbounds=pbounds, random_state=1)
optimizer.maximize(init_points=5, n_iter=10)

# Print the best hyperparameters and validation loss
print("Best hyperparameters:", optimizer.max['params'])
print("Best validation loss:", -optimizer.max['target'])